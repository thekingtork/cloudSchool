<?php

namespace cloud\siteBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class cloudBundle extends Bundle
{
}
